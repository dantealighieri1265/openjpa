package org.apache.openjpa.util.support;

public final class FinalClass {

}
